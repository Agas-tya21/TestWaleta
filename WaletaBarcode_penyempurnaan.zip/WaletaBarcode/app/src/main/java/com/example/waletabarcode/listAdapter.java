package com.example.waletabarcode;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class listAdapter extends ArrayAdapter {
    private final Activity context;
    private final ArrayList<String> itemData;


    public listAdapter(Activity context, ArrayList itemdata) {
        super(context, R.layout.listdata, itemdata);
        this.context = context;
        this.itemData = itemdata;

    }


    @Override
    public View getView(int position, View view, ViewGroup parent) {

        LayoutInflater inflater = context.getLayoutInflater();
        View rowView;
        rowView = inflater.inflate(R.layout.listdata, null, true);

        TextView txitem = (TextView) rowView.findViewById(R.id.item);

        txitem.setText(itemData.get(position));
        return rowView;
    }

    @Override
    public int getViewTypeCount() {

        return getCount();
    }

    @Override
    public int getItemViewType(int position) {

        return position;
    }
}
