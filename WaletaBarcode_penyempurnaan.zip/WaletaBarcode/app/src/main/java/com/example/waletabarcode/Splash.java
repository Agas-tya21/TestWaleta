package com.example.waletabarcode;

import static android.Manifest.permission.ACCESS_NETWORK_STATE;
import static android.Manifest.permission.ACCESS_WIFI_STATE;
import static android.Manifest.permission.CAMERA;
import static android.Manifest.permission.INTERNET;
import static android.Manifest.permission.READ_EXTERNAL_STORAGE;
import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.Window;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.HashMap;
import java.util.Map;

public class Splash extends AppCompatActivity {

    //@Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        EdgeToEdge.enable(this);
//        setContentView(R.layout.activity_splash);
//        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
//            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
//            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
//            return insets;
//        });
//    }

    public static final int RequestPermissionCoden = 6;
    private static final int PERMISSION_ALL = 0;
    private Handler h;
    private Runnable r;
    String[] PERMISSIONS = new String[] {WRITE_EXTERNAL_STORAGE,
            READ_EXTERNAL_STORAGE,
            INTERNET,
            ACCESS_NETWORK_STATE,
            ACCESS_WIFI_STATE,
            CAMERA};

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_splash);
        h = new Handler();
        r = new Runnable() {
            @Override
            public void run() {
                //Intent myIntent = new Intent(splash.this, Main2Activity.class);
                //myIntent.putExtra("boleh", "ok");
                //startActivity(myIntent);
                startActivity(new Intent(getApplicationContext(),MainActivity.class));
                finish();
            }
        };

        if (!UtilPermission.hasPermissions(this, PERMISSIONS)) {
            ActivityCompat.requestPermissions(this, PERMISSIONS, PERMISSION_ALL);
        }else{

            h.postDelayed(r, 1500);
        }
    }
    //Permission function starts from here
    private void RequestMultiplePermission() {
        // Creating String Array with Permissions.
        ActivityCompat.requestPermissions(this, new String[]
                {
                        WRITE_EXTERNAL_STORAGE,
                        READ_EXTERNAL_STORAGE,
                        INTERNET,
                        ACCESS_NETWORK_STATE,
                        ACCESS_WIFI_STATE,
                        CAMERA
                }, RequestPermissionCoden);

    }
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {

        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        int index = 0;
        Map<String, Integer> PermissionsMap = new HashMap<String, Integer>();
        for (String permission : permissions) {
            PermissionsMap.put(permission, grantResults[index]);
            index++;
        }

        if ((PermissionsMap.get(WRITE_EXTERNAL_STORAGE) != 0)
                || PermissionsMap.get(READ_EXTERNAL_STORAGE) != 0
                || PermissionsMap.get(INTERNET) != 0
                || PermissionsMap.get(ACCESS_NETWORK_STATE) != 0
                || PermissionsMap.get(ACCESS_WIFI_STATE) != 0
                || PermissionsMap.get(CAMERA) != 0) {
            ActivityCompat.requestPermissions(this, PERMISSIONS, PERMISSION_ALL);
            finish();
        } else {
            h.postDelayed(r, 1500);

        }
    }
}