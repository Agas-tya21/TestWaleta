package com.example.waletabarcode;

public class tbItem {
    public tbItem(String nmitem) {
        this.nmitem = nmitem;
    }

    String nmitem;
    public String getNmitem() {
        return nmitem;
    }
    public void setNmitem(String nmitem) {
        this.nmitem = nmitem;
    }
}
