package com.example.waletabarcode;

import android.content.pm.PackageManager;
import android.hardware.Camera;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.util.SparseArray;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.gms.vision.CameraSource;
import com.google.android.gms.vision.Detector;
import com.google.android.gms.vision.barcode.Barcode;
import com.google.android.gms.vision.barcode.BarcodeDetector;

import java.io.IOException;

import androidx.annotation.NonNull;

import org.w3c.dom.Text;

import java.lang.reflect.Field;
import java.util.ArrayList;


public class ScanBarcode extends AppCompatActivity {
    SurfaceView cameraView;
    CameraSource camsou;
    TextView barcodeInfo;
    String sKunci;
    ListView listku;
    listAdapter adapter;
    ArrayList<String> item;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_scan_barcode);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        item = new ArrayList<String>();
        cameraView = (SurfaceView) findViewById(R.id.camera_view);
        barcodeInfo = (TextView) findViewById(R.id.txbar1);
        listku = (ListView) findViewById(R.id.lsv1);
        BarcodeDetector barcodeDetector =
                new BarcodeDetector.Builder(this)
                        .setBarcodeFormats(Barcode.QR_CODE | Barcode.PDF417)//QR_CODE)
                        .build();
        if (!barcodeDetector.isOperational()) {
            Toast.makeText(getApplicationContext(), "Barcode Reader Error!!", Toast.LENGTH_SHORT).show();
            return;
        }
        camsou = new CameraSource.Builder(this, barcodeDetector)
                .setRequestedPreviewSize(640, 480)
                .setFacing(CameraSource.CAMERA_FACING_BACK)
                .setRequestedFps(30.f)
                .build();

        cameraView.getHolder().addCallback(new SurfaceHolder.Callback() {
            @Override
            public void surfaceCreated(SurfaceHolder holder) {

                try {
                    if (PackageManager.PERMISSION_GRANTED != ActivityCompat.checkSelfPermission(ScanBarcode.this, android.Manifest.permission.CAMERA)) {
                        // TODO: Consider calling
                        //    ActivityCompat#requestPermissions
                        // here to request the missing permissions, and then overriding
//                           public void onRequestPermissionsResult(int requestCode, String[] permissions,
//                                                                  int[] grantResults)
                        // to handle the case where the user grants the permission. See the documentation
                        // for ActivityCompat#requestPermissions for more details.
                        return;
                    }
                    camsou.start(cameraView.getHolder());
                    cameraFocus(camsou, Camera.Parameters.FOCUS_MODE_CONTINUOUS_VIDEO);
                    Toast.makeText(getApplicationContext(), "Barcode scanner ready!!", Toast.LENGTH_SHORT).show();
                } catch (IOException ie) {
                    Log.e("CAMERA SOURCE", ie.getMessage());
                }
            }

            @Override
            public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {

            }

            @Override
            public void surfaceDestroyed(SurfaceHolder holder) {
                camsou.stop();
            }
        });

        barcodeDetector.setProcessor(new Detector.Processor<Barcode>() {
            @Override
            public void release() {
            }
            @Override
            public void receiveDetections(Detector.Detections<Barcode> detections) {
                final SparseArray<Barcode> barcodes = detections.getDetectedItems();
                if (barcodes.size() != 0) {
                   barcodeInfo.post(new Runnable() {    // Use the post method of the TextView
                        public void run() {
                           // camsou.stop();

                            barcodeInfo.setText(barcodes.valueAt(0).displayValue);
                            sKunci = barcodeInfo.getText().toString();
                            playSuara();
                            item.add(sKunci);
                            adapter = new listAdapter(ScanBarcode.this,item);
                            listku.setAdapter(adapter);

                        }
                    });

                    //barcodeInfo.setText(barcodes.valueAt(0).displayValue);
                    //sKunci = barcodeInfo.getText().toString();
                    //playSuara();
                    //camsou.stop();
                    //Toast.makeText(getApplicationContext(), sKunci, Toast.LENGTH_SHORT).show();

                }
            }
        });
    }
    private void playSuara() {
        try{
            Uri notif = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            Ringtone r = RingtoneManager.getRingtone(getApplicationContext(),notif);
            r.play();
        }catch(Exception e){

        }


    }

    public static boolean cameraFocus(@NonNull CameraSource cameraSource, @NonNull String focusMode) {
        Field[] declaredFields = CameraSource.class.getDeclaredFields();

        for (Field field : declaredFields) {
            if (field.getType() == Camera.class) {
                field.setAccessible(true);
                try {
                    Camera camera = (Camera) field.get(cameraSource);
                    if (camera != null) {
                        Camera.Parameters params = camera.getParameters();

                        if (!params.getSupportedFocusModes().contains(focusMode)) {
                            return false;
                        }

                        params.setFocusMode(focusMode);
                        camera.setParameters(params);
                        return true;
                    }

                    return false;
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                }

                break;
            }
        }

        return false;

    }

    }

